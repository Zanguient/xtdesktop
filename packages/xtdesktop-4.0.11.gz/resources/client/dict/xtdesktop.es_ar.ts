<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">Escritorio</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Trial Balance</source>
        <translation></translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation type="unfinished">Libro Mayor</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>Contabilidad</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation type="unfinished">Cuentas x Pagar</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Proveedor</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation type="unfinished">Cuentas x Cobrar</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Budget</source>
        <translation type="unfinished">Presupuesto</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation type="unfinished">Póliza Estandar</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation type="unfinished">Reconciliar</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation type="unfinished">Transacciones</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation type="unfinished">Incidentes</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects</source>
        <translation type="unfinished">Proyectos</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Proyecto</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Cotizaciones</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation type="unfinished">Oportunidades</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation type="unfinished">Buró de Clientes</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation type="unfinished">Contactos</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do</source>
        <translation type="unfinished">Pendientes</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CRM</source>
        <translation type="unfinished">CRM</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Site</source>
        <translation type="unfinished">Sitio</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation type="unfinished">Inventario</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation type="unfinished">Comandos</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation type="unfinished">Lista de Materiales</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished">MetaSQL</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="unfinished">Roles</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation type="unfinished">Precios</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished">Moneda</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished">Scripts</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished">Partidas</translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Order Schedule</source>
        <translation></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation type="unfinished">Crear Orden de Trabajo</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation type="unfinished">Asentar Producción</translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished">Historial</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation type="unfinished">Cerrar Orden de Trabajo</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Costing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished">Procesar</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation></translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>ViewAPOpenItems</source>
        <translation></translation>
    </message>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation type="unfinished">Ingresar Recibos</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation type="unfinished">Auxiliar de Cheques</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation type="unfinished">Comprado</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished">Pago</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation type="unfinished">Crear Orden de Compra</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation type="unfinished">Órdenes de Compra</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation type="unfinished">Recibos No Asentados...</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Ship</source>
        <translation></translation>
    </message>
    <message>
        <source>Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Cotizaciones</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Ventas</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation type="unfinished">Mantenimiento a Embarques</translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation type="unfinished">Crear Factura</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation type="unfinished">Seleccionar para Facturar</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation type="unfinished">Asentar Facturas</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished">Imágenes</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished">Scripts</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished">Schema</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation type="unfinished">Privilegios</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished">MetaSQL</translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished">Base de datos</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Number</source>
        <translation></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">Ingreso</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Pasivo</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Activo</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Abrir...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Cant</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished">Liberar</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished">Explosionada</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished">En Proceso</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Planner Code</source>
        <translation></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Código de Clase</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">Código Producto</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Cant.</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Released</source>
        <translation></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished">En Proceso</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation type="unfinished">Cual</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation type="unfinished">Producto #</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">Orden #</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Fecha Inicio</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Recibido</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished">Ordenado</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation type="unfinished">UM</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished">Explosionada</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Dirección</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Ciudad</translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished">Número</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Contacto</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Teléfono</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Código Postal</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Account#</source>
        <translation></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">Nombre de Cuenta</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Teléfono</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Dirección</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Código Postal</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Ciudad</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>To-do</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Proyecto</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Fecha Inicio</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Prioridad</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">Cuenta #</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished">Propietario</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation type="unfinished">Incidente</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">Nombre de Cuenta</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">Tarea</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>0+ Days</source>
        <translation></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">61-90 Días {31-60 ?}</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Días</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Total Abierto</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished">61-90 Días</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Recibido</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Non-Inventory</source>
        <translation></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Proveedor</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">Código Producto</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Cant.</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Due Date</source>
        <translation></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">Orden #</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Teléfono</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Contacto</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Balance</source>
        <translation></translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Días</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished">61-90 Días</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Días</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">61-90 Días {31-60 ?}</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Total Abierto</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Orders</source>
        <translation></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Cotizaciones</translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation type="unfinished">Embarcado</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Today</source>
        <translation></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Ventas</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Cant.</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished">Rep. Ventas:</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Sched. Date</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation type="unfinished">Embarcar A</translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation type="unfinished">Facturar A</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">Orden #</translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># Internal</source>
        <translation></translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished">Nombre Propio</translation>
    </message>
    <message>
        <source># External</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished">Usuario</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Bienvenido</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation type="unfinished">Sitios</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Today</source>
        <translation></translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished">Rep. Ventas</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Ventas</translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Código de Clase</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Proveedor</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Producto</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Selection Preferences</source>
        <translation></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">Cuenta #</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Pasivo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Activo</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">Ingreso</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
