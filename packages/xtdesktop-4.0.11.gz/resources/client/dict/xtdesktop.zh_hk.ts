<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">桌面</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Aging</source>
        <translation type="unfinished">應收帳齡</translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>工作台</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>應收</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>廠商</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>帳戶</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>應付</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation>監視的科目</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>預算</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>客戶</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>銀行帳戶</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>總帳</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>會計科目表</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>標準傳票</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>調帳</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation>系列傳票</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>調整</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation>報告</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>財務報表</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>交易</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>試算表</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation type="unfinished">企業關係管理</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>時間及費用</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>專案訂單</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>報價</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>專案</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>我的聯絡人</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>事件</translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>客戶工作台</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>待辦事項</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>我的帳戶</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>帳戶管理</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>帳戶</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>企業</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>事件管理人</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>CRM</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>個人</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>待辦事項清單</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>待辦事項日曆</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>聯絡人</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>地址簿</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>預售</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>報價(依物品)</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>潛在客戶</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>機會</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>專案</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Reports</source>
        <translation>報告</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>貨幣</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>產品</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>物料清單</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>維護</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>項目</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>所在地</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>庫存</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>地點</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>使用者</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>排程</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>安全性</translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>價格</translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation>分配</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>角色</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>貨幣</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>匯率</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation>coin_clock_48</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>MetaSQL</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>畫面</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>延伸</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>指令碼</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>設計</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>指令</translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Return Material</source>
        <translation type="unfinished">退回物料</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>結束工作單</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>處理中</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation>廢料過帳</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation>更正生產</translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation>物料可用性</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>訂單排程</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>成本</translation>
    </message>
    <message>
        <source>History</source>
        <translation>歷史</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>製造活動</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>製造歷史</translation>
    </message>
    <message>
        <source>label</source>
        <translation>標籤</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation>生產過帳</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation>配給物料</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>建立工作單</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>可用庫存</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation>計畫</translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>製造</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation>物料需求</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>列印</translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation>工作單</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>釋出</translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Remind me about this again.</source>
        <translation type="unfinished">再次提示我關於這個</translation>
    </message>
    <message>
        <source>Notice</source>
        <translation>提示</translation>
    </message>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation>註記 : xTyple 桌面只提供給顯示漂浮視窗喜好選擇的使用者。</translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Purchase History</source>
        <translation type="unfinished">採購歷史</translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>採購訂單</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>未完結項目</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation>採購活動</translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation>ViewAPOpenItems</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>未開發票收據</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>連續支票 ...</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>帳齡</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>付款選擇</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>支票登記簿</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>採購</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>單據</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>選擇付款</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation>dspTimePhasedOpenAPItems</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>採購請求</translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>憑單</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>收貨</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>輸入收據</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>釋出</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>未過帳收貨單</translation>
    </message>
    <message>
        <source>label</source>
        <translation>標籤</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>可用庫存</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>建立採購單</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>列印</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Select for Billing</source>
        <translation type="unfinished">選取收帳</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>可用庫存</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>建立發票</translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>出貨</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>發票過帳</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>管理出貨</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation>列印包裝明細</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation>配給至出貨</translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation>現金收款</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation>銷售歷史</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>帳齡</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>新增銷售訂單</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>報價</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>新增客戶</translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation>銷售活動</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>潛在客戶</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>單據</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>銷售</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>label</source>
        <translation>標籤</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation>銷售訂單</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>收帳</translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation>積欠</translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished">b</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished">調帳 ...</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>餘額</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Scripts</source>
        <translation type="unfinished">指令碼</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation>儲存的程序</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation>自定指令</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>資料庫</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>圖片</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>觸發</translation>
    </message>
    <message>
        <source>Client</source>
        <translation>客戶</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>畫面</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>MetaSQL</translation>
    </message>
    <message>
        <source>Schema</source>
        <translation>模式名稱</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>報告</translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation>權限</translation>
    </message>
    <message>
        <source>Views</source>
        <translation>檢視</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>資料夾</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>編號</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重載</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>偏好 ...</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation>負債</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>資產</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>餘額</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>收入</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>支出</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>業主權益</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">重載</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">偏好 ...</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">開啟 ...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Planned</source>
        <translation type="unfinished">計畫</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>展開</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation>數量</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>釋出</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>處理中</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">計畫碼</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>數量</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>物品編號</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>等級碼</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>這個月</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重載</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>收貨</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>偏好 ...</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>這星期</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Order#</source>
        <translation type="unfinished">單據編號</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation>過帳值</translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation>有序工作值</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation>項目 #</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>處理中</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation>倉庫</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>已釋出</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>展開</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>已收貨</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation>單據</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation>狀況</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>到期日</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>開始日期:</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>單位</translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">名稱</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>編號</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>聯絡人</translation>
    </message>
    <message>
        <source>State</source>
        <translation>州/省</translation>
    </message>
    <message>
        <source>City</source>
        <translation>城市</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>電子郵件</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>郵編</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>國家</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Email</source>
        <translation type="unfinished">電子郵件</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>帳戶 #</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>帳戶名稱</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>郵編</translation>
    </message>
    <message>
        <source>State</source>
        <translation>州/省</translation>
    </message>
    <message>
        <source>City</source>
        <translation>城市</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>國家</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Incident</source>
        <translation type="unfinished">事件</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation>你是否確定永久刪除待辦事項項目?</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>擁有者</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation>事項</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>帳戶名稱</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>帳戶 #</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>客戶 #</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>開始日期</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>到期日</translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation>母編號</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation>刪除待辦事項?</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>專案</translation>
    </message>
    <message>
        <source>Task</source>
        <translation>工作</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>分配給</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>優先權</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">餘額</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0+ 天</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 天</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>總共未完結</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 天</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ 天</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 天</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Received</source>
        <translation type="unfinished">收貨</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation>憑單</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation>收貨</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>未釋出</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation>請求</translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation>確認</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>計畫</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">數量</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>偏好 ...</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重載</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>變數</translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation>非庫存</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation>採購代理</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>收貨</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>廠商</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>物品編號</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>這個月</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>這星期</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation>非庫存物品並不支援鑽取</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation>非支持的動作</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished">收貨電話</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation>廠商 #</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>單據編號</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>聯絡人</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>出貨地址聯絡人</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>運送方式</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>到期日</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>未釋出</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">餘額</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 天</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>總共未完結</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0+ 天</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ 天</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 天</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 天</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Pick</source>
        <translation type="unfinished">領料</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation>已出貨</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation>準備出貨</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>單據</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>報價</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation>列印</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation>已開發票</translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation>收帳</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">偏好 ...</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>數量</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation>銷售代表</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation>產品分類</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重載</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>預定</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>客戶</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>銷售</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>這個月</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>這星期</translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金額</translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation>排程日期</translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation>收款電話</translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation>收帳地址</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>運送方式</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>收貨電話</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>出貨地址聯絡人</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>客戶 #</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation>運送至</translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation>收款聯絡人</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>單據 #</translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">重載</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">偏好 ...</translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation type="unfinished"># 外部</translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation>客戶端地址</translation>
    </message>
    <message>
        <source># Internal</source>
        <translation># 內部</translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation>客戶端開始</translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation>開始查詢</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>電子郵件</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation>專有名稱</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>使用者名稱</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation type="unfinished">設定</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation>所在地</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>開啟 ...</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>歡迎</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">收據</translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation>依群組:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>類型：</translation>
    </message>
    <message>
        <source>This Month</source>
        <translation>這個月</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>預定</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>客戶</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation>產品分類</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>等級碼</translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation>銷售歷史喜好</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>項目</translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation>生產歷史喜好</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>變數</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>廠商</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>計畫碼</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>歷史設定</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>銷售</translation>
    </message>
    <message>
        <source>This Week</source>
        <translation>這星期</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation>採購代理</translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation>銷售代表</translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation>時間框:</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation>採購歷史喜好</translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Asset</source>
        <translation type="unfinished">資產</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation>負債</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation>選擇監視的科目:</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>業主權益</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>支出</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>收入</translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation>選擇喜好</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>科目 #</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
