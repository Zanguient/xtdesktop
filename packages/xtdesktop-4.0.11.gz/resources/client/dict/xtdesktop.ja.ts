<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">デスクトップ</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>dspBillingSelections</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>トランザクションs</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>勘定科目表</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation>仕訳シリーズ</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>試算表</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation>監視対象のアカウント</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>発生日</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>会計</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>買掛金</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>総勘定元帳</translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>ワークベンチ</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>財務諸表</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>予算</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>標準仕訳の履歴</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>顧客</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>ベンダー</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>売掛金</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>調整（アジャスメント）</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>消し込み</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>銀行口座</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation>レポート</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation type="unfinished">企業の関係管理</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>To Do リスト</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>イベントマネージャー</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>プロジェクト</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>個人</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>CRM</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>To Do カレンダー</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>時間と費用</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>企業</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>アカウントs</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>プロジェクトの受注</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>コンタクトs</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>アドレス帳</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>見込み</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>見積り</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>見込み</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>アイテムによる見積り</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation>プロジェクト</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>アカウントの管理</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>マイアカウント</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>インシデント</translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>顧客のワークベンチ</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>To Do</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>マイコンタクト</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Currencies</source>
        <translation>通貨s</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>拡張機能</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>レポート</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>デザイン</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>役割</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>スクリーン</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>在庫</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>商品</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>メンテナンス</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>コマンドs</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>部品表(BOM)</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>アイテム</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>価格（プライシング）</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>サイト(場所)</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>位置(場所)</translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation>割り当て</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>通貨</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>スケジュール</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>メタSQL</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>セキュリティ</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>スクリプト</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>ユーザー</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>交換レート</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Release</source>
        <translation type="unfinished">リリース</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>製造履歴</translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation>作業オーダー</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation>材料の返品</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>棚卸状況</translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>製造</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation>材料の要件</translation>
    </message>
    <message>
        <source>label</source>
        <translation>ラベル</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation>計画</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation>問題の材料</translation>
    </message>
    <message>
        <source>History</source>
        <translation>履歴</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>製造のアクティビティ</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>印刷</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>処理</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>作業オーダーの作成</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>作業オーダーを閉じる</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation>ポストスクラップ</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation>記帳 製品</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>原価</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>発注スケジュール</translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation>材料状況</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Remind me about this again.</source>
        <translation></translation>
    </message>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notice</source>
        <translation>注意</translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished">棚卸状況</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>選択した支払い</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>購入</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>実行を確認</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>発生日</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>購買リクエスト</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>小切手登録者</translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation>リリース</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>支払い</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>未記帳の領収書</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>アイテムを開く</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>発注</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>受領</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>発注書の作成</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>印刷</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>領収書の入力</translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>伝票s</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>支払いの選択</translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation>購入履歴</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>未請求の領収書</translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>購買発注</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>label</source>
        <translation>ラベル</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>label</source>
        <translation type="unfinished">ラベル</translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation>営業活動</translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation>現金領収書</translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>記帳 請求書</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>見込み</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>請求書の作成</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation>請求先の選択</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation>販売履歴:</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>請求先</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>新規顧客</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation>販売 注文</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>新規販売注文</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation>梱包リストの印刷</translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>配送</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>見積りs</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation>在庫</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>棚卸状況</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>送料を維持</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>エージング</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>発注</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>販売</translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished">b</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation>消し込み...</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>決算（精算）</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>スクリプト</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>テーブル</translation>
    </message>
    <message>
        <source>Schema</source>
        <translation>スキーマ</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>トリガー</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation>カスタムコマンド</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>スクリーン</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>イメージ</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>レポート</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>フォルダー</translation>
    </message>
    <message>
        <source>Views</source>
        <translation>表示</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>データベース</translation>
    </message>
    <message>
        <source>Client</source>
        <translation>クライアント</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation>ストアドプロシージャ</translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation>権限</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>メタSQL</translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">環境設定...</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation>債務</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>決算（精算）</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>タイプ</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>番号</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>補充</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>アセット（資産）</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>支出</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>収入</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>Equity</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">補充</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">環境設定...</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">開く...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>#</source>
        <translation type="unfinished">#</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>タイプ</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>計画した</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>処理の</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>リリースした</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>急増した</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">量(アマウント）</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>クラスコード</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>プランナーコード</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>アイテム番号</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今日</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>今月</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>補充</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>今週</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>環境設定...</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>領収</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished">WIPの値</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation>状態</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>単価</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>ステータス</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation>発注した</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation>記帳済み価格</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>発注#</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>支払日</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation>Whs.</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>受領</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>開始日</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation>アイテム #</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>急増した</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>リリースした</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>処理の</translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>State</source>
        <translation type="unfinished">都道府県</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>郵便番号</translation>
    </message>
    <message>
        <source>City</source>
        <translation>市</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>住所</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>コンタクト</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>電子メール</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>国</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>番号</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Email</source>
        <translation type="unfinished">電子メール</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>郵便番号</translation>
    </message>
    <message>
        <source>City</source>
        <translation>市</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>アカウント名</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>アカウント#</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>State</source>
        <translation>都道府県</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>住所</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>国</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation>インシデント</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <source>Task</source>
        <translation>タスク</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>プロジェクト</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>アカウント名</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation>To-Do</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation>To Doを削除しますか？</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>優先順位</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>所有者</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>アカウント#</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>顧客#</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>支払日</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>アサイン済み</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>ステータス</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>開始日</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation>親#</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">決算（精算）</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90 日</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30日</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>ステータス</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90日</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0 日</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>オープンの合計</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60日</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Firmed</source>
        <translation type="unfinished">確定</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation>バウチャー（割引券）</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>未リリース</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation>受領側</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>計画済み</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>タイプ</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation>リクエスト</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>受領済</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開く</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">アイテム番号</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>ベンダー</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>領収書</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation>代理人</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation>棚卸なし</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>環境設定...</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>補充</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>今月</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今日</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation>サポートされていないアクション</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>分散</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>今週</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished">未リリース</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>発送電話</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>発送連絡</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>電話</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>ステータス</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>コンタクト</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation>ベンダー#</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>発注#</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>経由出荷</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>支払日</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">決算（精算）</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0 日</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60日</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30日</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90 日</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>オープンの合計</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90日</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>ステータス</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">量(アマウント）</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation>請求書</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>タイプ</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation>印刷</translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation>請求先</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>見積もり</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation>出荷済み</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation>選択</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>発注</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation>配送中</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Product Category</source>
        <translation type="unfinished">製品カテゴリー</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>今月</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>今週</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>環境設定...</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>補充</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今日</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>予約</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>販売</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>顧客</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation>販売 責任者</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Order#</source>
        <translation type="unfinished">発注#</translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation>請求先 電話</translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation>請求の問い合わせ</translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation>請求先</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>顧客#</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>発送連絡</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation>配送先</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>量(アマウント）</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>発送電話</translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation>スケジュール日</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>経由出荷</translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">補充</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">環境設定...</translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation type="unfinished"># 外部</translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation>クライアントの住所</translation>
    </message>
    <message>
        <source># Internal</source>
        <translation>#内部</translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation>開始時のクエリー</translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation>クライアントの開始</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation>適切な名前</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>ユーザー名</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>電子メール</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Open...</source>
        <translation>開く...</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>セットアップ</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>ようこそ</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation>サイトs</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Sales History Preferences</source>
        <translation></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">今日</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished">販売 責任者</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">顧客</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>仕入先</translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished">グループごと：</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">プランナーコード</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">アイテム</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">販売</translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">クラスコード</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished">予約</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished">製品カテゴリー</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished">分散</translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Revenue</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>Equity</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">説明</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">アセット（資産）</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">債務</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">支出</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">アカウント#</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
