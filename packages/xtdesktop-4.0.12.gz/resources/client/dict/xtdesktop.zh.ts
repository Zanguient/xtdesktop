<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">桌面</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Receivables</source>
        <translation type="unfinished">应收款</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>对帐调整</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>财务</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>移库</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>试算平衡</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation>报表</translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>工作台</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation type="unfinished">标准日记账</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">客户</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>银行帐户</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>预算</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>会计科目表</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>对帐调节</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">供应商</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>财务报表</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>总分类帐</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>账龄</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>应付款</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>团体</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>待完成列表</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>待处理日程</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>售前</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>联系人</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>项目:</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>账户</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>事件</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>机会</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>任务列表</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>地址薄</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>项目:</translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>客户工作台</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>项目订单</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>时间 &amp; 开销</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>账户管理</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>事件管理器</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>我的联系人</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>我的账户</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>个人</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>客户关系管理</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>报价</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>潜在客户</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>依物品报价</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Assignments</source>
        <translation>价格确定</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>脚本</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>角色</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>命令</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>设计</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>屏幕</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>汇率</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>报表</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished">货币</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>货币</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>价格计划</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>维护</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>安全</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>物料清单</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>产品</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>物料</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>库存</translation>
    </message>
    <message>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>核价</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished">签发物料...</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation>退回制令单物料</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>下达制令单</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation>修正制令单过账</translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation>材料可用量</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>制令单排程</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>制造活动</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>制造历史</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>库存可用量</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>制造流程</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation>废品过账</translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation>制令单</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>关闭制令单</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation>制造计划</translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>制造</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>成本计算</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation>成品入库过账...</translation>
    </message>
    <message>
        <source>History</source>
        <translation>制令单历史</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation>物料需求</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>创建制令单</translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation></translation>
    </message>
    <message>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Enter Receipts</source>
        <translation type="unfinished">输入收货单</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>采购申请</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>采购</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>采购订单</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>创建采购订单</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>库存可用量</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>收货</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>下达采购订单</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>未过帐的收货单</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>账龄</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>支票运行</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>选择付款</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>付款凭单</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>已选择的付款列表</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>支票登记</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>未开发票的收货单</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation>采购历史</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation>采购事务</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>未清应付款</translation>
    </message>
    <message>
        <source>label</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>采购订单</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Aging</source>
        <translation type="unfinished">账龄</translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>发票过账</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation>现金收据</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>订单</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>销售</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>新客户</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>潜在客户</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>报价单</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>新销售订单</translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>发货</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation>采购订单</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation>销售活动</translation>
    </message>
    <message>
        <source>label</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation>销售历史</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation>打印装箱单</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>发货维护</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation>为发货签发物料</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>库存可用量</translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation>积压</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>创建发票</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>账单</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation>选择已发货订单以便开帐单</translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation>对帐调节...</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Views</source>
        <translation></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished">图片</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation>自定义命令</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished">脚本</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>屏幕</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>报表</translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation>权限</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>数据库</translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Reload</source>
        <translation></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished">编号</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">资产</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">收入</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">负债</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">打开...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Exploded</source>
        <translation type="unfinished">已展开</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>已下达</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>处理中</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">数量</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">收据</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>本周</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">今天</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Whs.</source>
        <translation></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation type="unfinished">物料#</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">订单#</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished">截止日期</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">开始日期</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation>已收到</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>已展开</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>处理中</translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished">已下达</translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">联系人</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">电话</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished">编号</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">城市</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">地址</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished">国家</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">省</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>邮政编码</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>邮政编码</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished">国家</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">省</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">地址</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">城市</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">帐号＃:</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">电话</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">帐户名</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">名字</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Project</source>
        <translation></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation type="unfinished">父项编号</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">优先级</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">任务</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation>事件</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">帐号＃:</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation>删除待处理事项吗?</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation>永久删除此待处理事项。你确认吗?</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">帐户名</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished">所有者</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation type="unfinished">待办事项</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">删除</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">开始日期</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">名字</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished">截止日期</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation type="unfinished">分派给</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>31-60 Days</source>
        <translation></translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">61-90天 {0-30 ?}</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0天以上</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">未决定总数</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation>已收到</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>未下达的采购订单</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation>采购申请</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">数量</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>本周</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">今天</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">收据</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation type="unfinished">非库存</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">供应商</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Due Date</source>
        <translation></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>未下达的采购订单</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished">承运商</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">电话</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">联系人</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">订单#</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>90+ days</source>
        <translation></translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">未决定总数</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0天以上</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">61-90天 {31-60 ?}</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">61-90天 {0-30 ?}</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Shipped</source>
        <translation></translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished">订单</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation type="unfinished">在途</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished">销售代表.</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>数量</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">描述</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">客户</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">今天</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>销售</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>本周</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Bill To</source>
        <translation type="unfinished">账单地址：</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation type="unfinished">送货地址</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished">订单#</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">金额</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished">承运商</translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation type="unfinished">已安排的日期</translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># Internal</source>
        <translation></translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source># External</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished">用户名</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">电子邮箱地址:</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation type="unfinished">仓库</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>欢迎</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">打开...</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Product Category</source>
        <translation></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation>本周</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>销售</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">类型:</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">客户</translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation>销售代表</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">收据</translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">今天</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">供应商</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation>采购代理</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">物料</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">资产</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">负债</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">收入</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished">帐号＃:</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
